multiwalker_base.py Includes modifications to the original PettingZoo Multiwalker environment. These changes introduce custom reward shaping functions designed to enhance agent coordination and performance.

train.py Script used to train a reinforcement learning model within the Multiwalker environment using the reward shaping methods.

evaluate.py Script for evaluating the performance of a trained model. This evaluates how far the package can be carried to, which can also be regarded as a distance between current policy and the optimal policy.

eval.py Script for generating videos.

"result models" are our trained models